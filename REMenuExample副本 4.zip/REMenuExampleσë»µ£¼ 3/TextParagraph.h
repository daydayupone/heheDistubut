//
//  TextParagraph.h
//  tangyuanReader
//
//  Created by 王 强 on 13-6-7.
//  Copyright (c) 2013年 中文在线. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TextParagraph : NSObject
@property (nonatomic, strong) NSString *key;
@end

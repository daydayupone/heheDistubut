//
//  CAParagraphLayer.h
//  FastTextView
//
//  Created by 王 强 on 13-8-1.
//  Copyright (c) 2013年 wangqiang. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "FastTextStorage.h"

@interface CAParagraphLayer : CALayer


@end

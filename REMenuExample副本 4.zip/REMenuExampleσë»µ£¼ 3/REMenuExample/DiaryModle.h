//
//  DiaryModle.h
//  REMenuExample
//
//  Created by jiawei on 14-1-11.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DiaryModle : NSObject

@property (nonatomic, copy) NSString *time;
@property (nonatomic, copy) NSString *content;
    
@end

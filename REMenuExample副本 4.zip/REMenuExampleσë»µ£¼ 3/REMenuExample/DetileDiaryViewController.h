//
//  DetileDiaryViewController.h
//  REMenuExample
//
//  Created by jiawei on 14-1-8.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import "HomeViewController.h"

@interface DetileDiaryViewController : HomeViewController

@property (nonatomic, strong) NSDictionary *dairyDic;
@property (nonatomic, assign) int plistIndx;

@end

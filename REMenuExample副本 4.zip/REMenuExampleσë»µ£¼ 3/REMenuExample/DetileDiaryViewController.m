//
//  DetileDiaryViewController.m
//  REMenuExample
//
//  Created by jiawei on 14-1-8.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import "DetileDiaryViewController.h"

@interface DetileDiaryViewController ()

@end

@implementation DetileDiaryViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)backAction{
    
    NSLog(@"backAction");
    [self.navigationController popViewControllerAnimated:YES];
    
}

    
- (void)deleteAction{
    
    UIAlertView *sureDelete = [[UIAlertView alloc]initWithTitle:nil message:NSLocalizedString(@"qdscrj", nil) delegate:self cancelButtonTitle:nil otherButtonTitles:NSLocalizedString(@"qd", nil),NSLocalizedString(@"qx", nil), nil];
    [sureDelete show];
    
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    self.emotion.enabled = NO;
    [self.emotion setImage:[UIImage imageNamed:[self.dairyDic objectForKey:dicEmotion]] forState:UIControlStateDisabled];
    
    self.weather.enabled = NO;
    [self.weather setImage:[UIImage imageNamed:[self.dairyDic objectForKey:dicWeather]] forState:UIControlStateDisabled];
    
    
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    backButton.frame = CGRectMake(0, 0, 30, 40);
    [backButton setImage:[UIImage imageNamed:@"backBtnImage_.png"] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:backButton];
    
    self.navigationItem.titleView = nil;
    self.navigationItem.rightBarButtonItem = nil;
    
    self.contentTextView.text = [self.dairyDic objectForKey:dicContent];
    self.contentTextView.frame = CGRectMake(10, 10, kScreenWidth-40, kScreenHeight-220);
    self.contentTextView.editable = NO;
    
    if ([self.dairyDic objectForKey:dicImage]) {
        
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            
            UIImage *img = [UIImage imageWithContentsOfFile:[self.dairyDic objectForKey:dicImage]];
            self.myPicture.frame =  CGRectMake(0, 10, kScreenWidth-60, 120);
            [self.myPicture setImage:[UIImage imageNamed:@"AlbumBtnNormal_.png"]];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [self.myPicture setImage:img];
                
                self.myPicture.backgroundColor = [UIColor clearColor];
                self.contentTextView.frame = CGRectMake(10, 130, kScreenWidth-40, kScreenHeight-220);
                
            });
        });
        
        
    }
    
    UIButton *delectBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    delectBtn.frame = CGRectMake(0, 0, 30, 30);
    [delectBtn setImage:[UIImage imageNamed:@"glyphicons_016_bin_.png"] forState:UIControlStateNormal];
    [delectBtn addTarget:self action:@selector(deleteAction) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:delectBtn];
    
    
    
}
#pragma mark -- UIAlertDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:
        {
            NSLog(@"deleteAtion idx == %d",self.plistIndx);
            NSMutableArray *diaryAr = [NSMutableArray arrayWithContentsOfFile:[kDocumentPath stringByAppendingPathComponent:kDiaryName]];
            [diaryAr removeObjectAtIndex:self.plistIndx];
            [diaryAr writeToFile:[kDocumentPath stringByAppendingPathComponent:kDiaryName] atomically:YES];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"sxjm" object:nil];
            [self.navigationController popViewControllerAnimated:YES];
        }
        break;
        
        default:
        break;
    }
}
    
- (void)didReceiveMemoryWarning
{
    
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    if ([self.view window] == nil)
    {
        // Add code to preserve data stored in the views that might be
        // needed later.
        // Add code to clean up other strong references to the view in
        // the view hierarchy.
        self.view = nil;
    }
}


- (void) viewDidUnload {
    NSLog(@"viewDidUnload");
    [super viewDidUnload];
    super.myPicture = nil;
    self.myPicture = nil;
    self.timeLabel = nil;
    self.contentTextView = nil;
    self.emotion = nil;
    self.weather = nil;
    self.emotionMenu = nil;
    self.weatherMenu = nil;
}
@end

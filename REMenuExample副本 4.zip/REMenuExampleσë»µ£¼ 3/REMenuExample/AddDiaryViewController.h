//
//  AddDiaryViewController.h
//  REMenuExample
//
//  Created by jiawei on 14-1-6.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "MMProgressHUDOverlayView.h"
#import "MMProgressHUD.h"
#import "SVProgressHUD.h"

@interface AddDiaryViewController : UIViewController<UITextViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>


@end

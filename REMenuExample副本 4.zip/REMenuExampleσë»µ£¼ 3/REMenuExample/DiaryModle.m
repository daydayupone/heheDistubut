//
//  DiaryModle.m
//  REMenuExample
//
//  Created by jiawei on 14-1-11.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import "DiaryModle.h"

@implementation DiaryModle

@end
